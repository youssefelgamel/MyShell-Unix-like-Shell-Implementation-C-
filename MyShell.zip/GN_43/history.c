#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_HISTORY 100

char *history[MAX_HISTORY];
int history_count = 0;

void add_to_history(char *cmd) {
	if (history_count >= MAX_HISTORY) {
		free(history[0]);
	        for (int i = 1; i < MAX_HISTORY; i++) {
           		 history[i-1] = history[i];
       		 }
       		 history_count = MAX_HISTORY - 1;
	}
	cmd[strcspn(cmd, "\n")] = '\0';

	history[history_count] = strdup(cmd);
	history_count++;
}

void print_history() {
    for (int i = 0; i < history_count; i++) {
        printf("%d  %s\n", i + 1, history[i]);
    }
}

char *run_history_command(int n) {
    if (n < 1 || n > history_count) {
        printf("myShell: !%d: event not found\n", n);
        return NULL;
    }
    return history[n - 1];
}

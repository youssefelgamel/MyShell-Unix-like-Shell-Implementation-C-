#ifndef BUILTINS_H
#define BUILTINS_H

/* Task 4 — Mohamed Saad
 * Built-in commands: cd and pwd
 * These run inside the shell process (no fork needed).
 */

void builtin_cd(char **args);
void builtin_pwd(void);

#endif

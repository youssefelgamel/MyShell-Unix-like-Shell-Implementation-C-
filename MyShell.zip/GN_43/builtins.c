#include "builtins.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>   /* PATH_MAX */

/* ---------------------------------------------------------------
 * Task 4 — Mohamed Saad
 * Built-in: cd
 *
 *  cd          → go to $HOME
 *  cd -        → go to previous directory ($OLDPWD)
 *  cd <path>   → chdir() to the given path
 * --------------------------------------------------------------- */
void builtin_cd(char **args) {
    char cwd[PATH_MAX];
    const char *target;

    /* Save current directory as OLDPWD before we move */
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        setenv("OLDPWD", cwd, 1);
    }

    if (args[1] == NULL) {
        /* cd with no argument → go home */
        target = getenv("HOME");
        if (target == NULL) {
            fprintf(stderr, "cd: HOME not set\n");
            return;
        }
    } else if (strcmp(args[1], "-") == 0) {
        /* cd - → go to previous directory */
        target = getenv("OLDPWD");
        if (target == NULL) {
            fprintf(stderr, "cd: OLDPWD not set\n");
            return;
        }
        printf("%s\n", target);   /* bash prints the destination on cd - */
    } else {
        target = args[1];
    }

    if (chdir(target) != 0) {
        perror("cd");
        return;
    }

    /* Update $PWD to the real (resolved) path */
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        setenv("PWD", cwd, 1);
    }
}

/* ---------------------------------------------------------------
 * Task 4 — Mohamed Saad
 * Built-in: pwd
 *
 * Prints the current working directory using getcwd().
 * --------------------------------------------------------------- */
void builtin_pwd(void) {
    char cwd[PATH_MAX];

    if (getcwd(cwd, sizeof(cwd)) == NULL) {
        perror("pwd");
        return;
    }
    printf("%s\n", cwd);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

#include "history.h"
#include "signals.h"
#include "builtins.h"   /* Task 4: cd, pwd */

int main() {
    char input[1024];
    char *args[64];

    setup_signal_handlers();   /* Task 9: ignore SIGINT/SIGTSTP in shell */

    while (1) {
        printf("myShell> ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL) break;
        input[strcspn(input, "\n")] = '\0';

        if (strlen(input) == 0) continue;

        add_to_history(input);   /* Task 5: record every command */

        if (strcmp(input, "exit") == 0) break;

        /* ===================== Tokenize ===================== */
        int i = 0;
        char *token = strtok(input, " ");
        while (token != NULL && i < 63) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;

        if (args[0] == NULL) continue;

        /* ================= Detect operators ================= */
        int hasPipe = 0, hasOut = 0, hasIn = 0, background = 0;
        for (int j = 0; args[j] != NULL; j++) {
            if (strcmp(args[j], "|") == 0) hasPipe  = 1;
            if (strcmp(args[j], ">") == 0) hasOut   = 1;
            if (strcmp(args[j], "<") == 0) hasIn    = 1;
            if (strcmp(args[j], "&") == 0) background = 1;
        }

        /* Remove & from args so exec doesn't see it */
        if (background) {
            for (int j = 0; args[j] != NULL; j++) {
                if (strcmp(args[j], "&") == 0) {
                    args[j] = NULL;
                    break;
                }
            }
        }

        /* ================== Built-in Commands ================== */

        /* Task 5: history */
        if (strcmp(args[0], "history") == 0) {
            print_history();
            continue;
        }

        /* Task 5: !n — re-run command n */
if (args[0][0] == '!') {
    int n = atoi(args[0] + 1);
    char *cmd = run_history_command(n);
    if (cmd != NULL) {
        strncpy(input, cmd, sizeof(input) - 1);
        input[sizeof(input) - 1] = '\0';
        printf("%s\n", input);

        /* Re-tokenize and fall through to execution */
        i = 0;
        char inputCopy[1024];
        strncpy(inputCopy, input, sizeof(inputCopy) - 1);
        token = strtok(inputCopy, " ");
        while (token != NULL && i < 63) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL;
    } else {
        continue;
    }
}

        /* Task 4: cd */
        if (strcmp(args[0], "cd") == 0) {
            builtin_cd(args);
            continue;
        }

        /* Task 4: pwd */
        if (strcmp(args[0], "pwd") == 0) {
            builtin_pwd();
            continue;
        }

        /* ====================== PIPE ====================== */
        /* Task 8 */
        if (hasPipe) {
            char *cmd1[20];
            char *cmd2[20];
            int splitIndex = -1;

            for (int j = 0; args[j] != NULL; j++) {
                if (strcmp(args[j], "|") == 0) { splitIndex = j; break; }
            }

            if (splitIndex <= 0 || args[splitIndex + 1] == NULL) {
                fprintf(stderr, "myShell: invalid pipe usage\n");
                continue;
            }

            for (int j = 0; j < splitIndex; j++) cmd1[j] = args[j];
            cmd1[splitIndex] = NULL;

            int k = 0;
            for (int j = splitIndex + 1; args[j] != NULL; j++) cmd2[k++] = args[j];
            cmd2[k] = NULL;

            int fd[2];
            if (pipe(fd) < 0) { perror("pipe"); continue; }

            pid_t pid1 = fork();
            if (pid1 < 0) { perror("fork"); continue; }

            if (pid1 == 0) {                  /* child 1 — writes */
                restore_default_signals();
                dup2(fd[1], STDOUT_FILENO);
                close(fd[0]); close(fd[1]);
                execvp(cmd1[0], cmd1);
                perror("execvp cmd1");
                exit(1);
            }

            pid_t pid2 = fork();
            if (pid2 < 0) { perror("fork"); continue; }

            if (pid2 == 0) {                  /* child 2 — reads */
                restore_default_signals();
                dup2(fd[0], STDIN_FILENO);
                close(fd[1]); close(fd[0]);
                execvp(cmd2[0], cmd2);
                perror("execvp cmd2");
                exit(1);
            }

            close(fd[0]); close(fd[1]);

            if (background) {
                printf("[Background PIDs]: %d %d\n", pid1, pid2);
            } else {
                int status;
                waitpid(pid1, &status, WUNTRACED);
                waitpid(pid2, &status, WUNTRACED);
            }
            continue;
        }

        /* ================ I/O Redirection ================ */
        /* Task 7 */
        if (hasOut || hasIn) {
            char *cmd[20];
            char *outFile = NULL;
            char *inFile  = NULL;
            int  k = 0;

            for (int j = 0; args[j] != NULL; j++) {
                if (strcmp(args[j], ">") == 0 && args[j+1] != NULL) {
                    outFile = args[++j];
                } else if (strcmp(args[j], "<") == 0 && args[j+1] != NULL) {
                    inFile = args[++j];
                } else {
                    cmd[k++] = args[j];
                }
            }
            cmd[k] = NULL;

            if (cmd[0] == NULL) { fprintf(stderr, "myShell: no command given\n"); continue; }

            pid_t pid = fork();
            if (pid < 0) { perror("fork"); continue; }

            if (pid == 0) {
                restore_default_signals();

                if (outFile) {
                    int fd = open(outFile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                    if (fd < 0) { perror("open >"); exit(1); }
                    dup2(fd, STDOUT_FILENO);
                    close(fd);
                }
                if (inFile) {
                    int fd = open(inFile, O_RDONLY);
                    if (fd < 0) { perror("open <"); exit(1); }
                    dup2(fd, STDIN_FILENO);
                    close(fd);
                }

                execvp(cmd[0], cmd);
                fprintf(stderr, "myShell: %s: command not found\n", cmd[0]);
                exit(EXIT_FAILURE);
            } else {
                if (background)
                    printf("[Background PID]: %d\n", pid);
                else {
                    int status;
                    waitpid(pid, &status, WUNTRACED);
                }
            }
            continue;
        }

        /* ================== Normal Command ================== */
        /* Task 3 */
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); exit(EXIT_FAILURE); }

        if (pid == 0) {
            restore_default_signals();
            execvp(args[0], args);
            fprintf(stderr, "myShell: %s: command not found\n", args[0]);
            exit(EXIT_FAILURE);
        } else {
            if (background)
                printf("[Background PID]: %d\n", pid);
            else {
                int status;
                waitpid(pid, &status, WUNTRACED);
            }
        }
    }

    return 0;
}

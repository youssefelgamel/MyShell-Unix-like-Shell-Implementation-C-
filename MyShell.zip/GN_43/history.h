#ifndef HISTORY_H
#define HISTORY_H

void add_to_history(char *cmd);
void print_history(void);
char *run_history_command(int n);

#endif

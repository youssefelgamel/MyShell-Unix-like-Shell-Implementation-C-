# myShell — OUR Linux Shell
---------------------------

# Project Description
myShell is a simplified Unix shell implemented in C.
It supports basic command execution, built-in commands, pipes, redirection, background execution, and signal handling.

---

# Features
- Command execution using fork & exec
- Built-in commands: cd, pwd, history, exit
- Command history with !n re-execution
- Pipes (|)
- Input/output redirection (< , >)
- Background processes (&)
- Signal handling (ctrl+C, Ctrl+Z)

---

#Credits

1.
Marwan Ehab Adel
2401248195
I/O Redirections

2.
Nour "Eldeen" Ali El-Kholy
2401244543
Error Handling, Makefile & README

3.
Mohamed saad Ibrahim morshidy 
2401249732
Built-in: cd & pwd

4.
Fares Hesham Mohammed 
2401242508
Built-in History

5.
Youssef Ramadan Ahmed 
2401247684
Command Parser

6.
Mahmoud Abdelrahman Abdullatif Hassan 
2401244698
Signal Handling

7.
Fares Ahmed Loutfy 
2401249428
Loop(backbone of the project)

8.
Mohamed Allam Mahmoud
2401243978
Pipe

9.
Marwan Ahmed El Sayed El Mahdi
2401248710
Background Excution

10.
Mo'men Osama Galal Awad 
2401247521
Command Execution
---
